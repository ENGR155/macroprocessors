param([string]$Iverilog='iverilog',[string]$Vvp='vvp')
$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
    New-Item -ItemType Directory -Force build | Out-Null
    & $Iverilog -g2012 -s tb_spi_echo -o build/tb_spi_echo spi_echo.sv tb_spi_echo.sv
    if($LASTEXITCODE) { throw 'SPI echo simulation compilation failed' }
    & $Vvp build/tb_spi_echo
    if($LASTEXITCODE) { throw 'SPI echo simulation failed' }
} finally { Pop-Location }
