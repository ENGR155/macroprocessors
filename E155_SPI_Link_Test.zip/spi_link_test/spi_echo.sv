// Standalone E155 carrier-board SPI link test. No ADC, PWM, or controller.
module spi_echo_core (
    input wire clk, rst, sck, cs_n, mosi,
    output wire miso,
    output reg accepted_led, rejected_led,
    output reg [31:0] accepted_count, rejected_count
);
    (* ASYNC_REG="TRUE" *) reg [2:0] cs_sync=3'b111, sck_sync=0, mosi_sync=0;
    reg [63:0] rx_shift, tx_shift, reply;
    reg [6:0] bit_count;
    wire cs_fall=cs_sync[2] && !cs_sync[1];
    wire cs_rise=!cs_sync[2] && cs_sync[1];
    wire sck_rise=!sck_sync[2] && sck_sync[1];
    wire sck_fall=sck_sync[2] && !sck_sync[1];
    wire [55:0] reply_body={8'h5a,rx_shift[55:48],~rx_shift[47:8]};
    function automatic [7:0] xor7(input [55:0] body);
        begin
            xor7=0;
            for(integer i=0;i<7;i=i+1) xor7=xor7 ^ body[i*8+:8];
        end
    endfunction
    // Release the shared wire immediately when deselected, including reset.
    assign miso=cs_n ? 1'bz : tx_shift[63];
    always @(posedge clk) begin
        cs_sync<={cs_sync[1:0],cs_n};
        sck_sync<={sck_sync[1:0],sck};
        mosi_sync<={mosi_sync[1:0],mosi};
        if(rst) begin
            rx_shift<=0; tx_shift<=0; bit_count<=0;
            reply<=64'h5a0000000000005a;
            accepted_led<=0; rejected_led<=0;
            accepted_count<=0; rejected_count<=0;
        end else if(cs_fall) begin
            tx_shift<=reply; rx_shift<=0; bit_count<=0;
        end else if(cs_rise) begin
            if(bit_count==64 && rx_shift[63:56]==8'ha5 &&
               xor7(rx_shift[63:8])==rx_shift[7:0]) begin
                reply<={reply_body,xor7(reply_body)};
                accepted_count<=accepted_count+1'b1;
                accepted_led<=~accepted_led;
            end else begin
                rejected_count<=rejected_count+1'b1;
                rejected_led<=1;
            end
        end else if(!cs_sync[1]) begin
            if(sck_rise) begin
                rx_shift<={rx_shift[62:0],mosi_sync[1]};
                if(bit_count<65) bit_count<=bit_count+1'b1;
            end
            if(sck_fall) tx_shift<={tx_shift[62:0],1'b0};
        end
    end
endmodule

module spi_echo_top (
    input wire sck, cs_n, mosi,
    output wire miso, heartbeat_led, accepted_led, rejected_led
);
    wire clk;
`ifdef RADIANT
    HSOSC #(.CLKHF_DIV("0b01")) osc(.CLKHFPU(1'b1),.CLKHFEN(1'b1),.CLKHF(clk));
`else
    SB_HFOSC #(.CLKHF_DIV("0b01")) osc(.CLKHFPU(1'b1),.CLKHFEN(1'b1),.CLKHF(clk));
`endif
    reg [12:0] por=0;
    reg [23:0] heartbeat=0;
    always @(posedge clk) begin
        if(!por[12]) por<=por+1'b1;
        heartbeat<=heartbeat+1'b1;
    end
    wire rst=!por[12];
    assign heartbeat_led=heartbeat[23];
    spi_echo_core core(.clk(clk),.rst(rst),.sck(sck),.cs_n(cs_n),.mosi(mosi),
        .miso(miso),.accepted_led(accepted_led),.rejected_led(rejected_led),
        .accepted_count(),.rejected_count());
endmodule
