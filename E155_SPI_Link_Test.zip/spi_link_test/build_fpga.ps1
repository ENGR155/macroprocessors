param([string]$Yosys='yosys',[string]$Nextpnr='nextpnr-ice40',[string]$Icepack='icepack')
$ErrorActionPreference='Stop'
Push-Location $PSScriptRoot
try {
    New-Item -ItemType Directory -Force build | Out-Null
    & $Yosys -p 'read_verilog -sv spi_echo.sv; synth_ice40 -device u -top spi_echo_top -json build/spi_echo.json'
    if($LASTEXITCODE) { throw 'SPI echo synthesis failed' }
    & $Nextpnr --up5k --package sg48 --json build/spi_echo.json --pcf spi_echo.pcf --asc build/spi_echo.asc --freq 24
    if($LASTEXITCODE) { throw 'SPI echo place/route failed' }
    & $Icepack build/spi_echo.asc build/spi_echo.bin
    if($LASTEXITCODE) { throw 'SPI echo bitstream packing failed' }
    Write-Output 'Built build/spi_echo.bin. Program with your established UPduino workflow.'
} finally { Pop-Location }
