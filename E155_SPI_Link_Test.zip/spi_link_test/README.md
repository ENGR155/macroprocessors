# E155 development board: MCU-to-FPGA SPI test

**Goal:** Pass known bytes from the NUCLEO-L432KC to the UPduino v3.1, transform them on the FPGA, and verify the returned bytes on the MCU. **No ADC, Hall sensors, electromagnet, DMA, Wi-Fi, or control loop is needed.**

This is a standalone test. Use its two small programs rather than the levitation firmware or the proposed position-PI protocol. Existing application sources remain unchanged. The test uses a simple XOR checksum to aid diagnosis; the final application should retain its stronger CRC.

## 1. Use the carrier board's built-in SPI connections

The [E155 carrier schematic, Rev v4](https://hmc-e155.github.io/assets/doc/E155%20Development%20Board%20Schematic.pdf) shows four SPI connections through the **eight-position bridge switch SW7**. Close only its SPI positions:

| SW7 position | Setting | Connection when closed |
|---:|---|---|
| 1 | **OFF/open** | PA10 to FPGA P23, UART RX |
| 2 | **OFF/open** | PA9 to FPGA P25, UART TX |
| 3 | **OFF/open** | PA5 to FPGA P26, I2C SDA |
| 4 | **OFF/open** | PA6 to FPGA P27, I2C SCL |
| 5 | **ON/closed** | **PA11 / D10 to FPGA P20: CS** |
| 6 | **ON/closed** | **PB5 / D11 to FPGA P10: MOSI** |
| 7 | **ON/closed** | **PB4 / D12 to FPGA P12: MISO** |
| 8 | **ON/closed** | **PB3 / D13 to FPGA P21: SCK** |

**These are SW7 switch positions, not FPGA package pins or connector positions.** Use the numbered switch body and its ON marking, not a guess about left/right orientation. If numbering is unclear, check continuity with power removed. In the schematic, the CS switch joins SW7 contacts **5 and 12**, MOSI **6 and 11**, MISO **7 and 10**, and SCK **8 and 9**.

This built-in route is different from the earlier explicit-jumper proposal using PA4/PA5/PA6/PA7 and FPGA P25/P23/P27/P26. **Do not combine the two maps.** The supplied MCU code deliberately uses PB3/PB4/PB5, and its CS is PA11.

The separate **four-position SW6** is a bank of grounded user-input switches, not the MCU-FPGA bridge. Leave SW6 off for this test. You do not need to change Nucleo SB16/SB18 for this PB3/PB4/PB5 route.

### Power and preparation

1. With power removed, seat both modules in the correct orientation and inspect for offset headers.
2. Remove any previous SPI jumper wires and leave the mikroBUS/ESP module disconnected for this standalone test.
3. Set SW7 as above. Leave the external VIN screw terminal unpowered.
4. For **separate USB power to each module**, leave the carrier's **J3 and J4 power jumpers open**: these jumpers join each module's 5 V rail to the carrier 5 V rail. Each module then powers itself from its USB connection; the carrier already shares their grounds.
5. Connect both USB data cables. Keep all logic at **3.3 V** and use the UPduino's normal 3.3 V I/O-bank configuration. No external supply is needed for this test.

Match your physical carrier revision against the schematic before using its jumper names. The carrier's VIN-powered LEDs/regulators need not be powered in the separate-USB arrangement. Do not infer failure from the VIN power LED being off.

## 2. Files supplied

| File | Purpose |
|---|---|
| [spi_echo.sv](spi_echo.sv) | FPGA mode-0 slave, delayed transformed echo, heartbeat and activity indicators |
| [spi_echo.pcf](spi_echo.pcf) | Open-source-toolchain pin assignments for the SW7 route |
| [mcu_spi_test.c](mcu_spi_test.c) | Standalone polling SPI master and debugger-visible results |
| [tb_spi_echo.sv](tb_spi_echo.sv) | HDL simulation of valid/malformed traffic and reset |
| [run_sim.ps1](run_sim.ps1) | Optional Icarus simulation helper |
| [build_fpga.ps1](build_fpga.ps1) | Optional OSS CAD Suite FPGA build helper |

Program **spi_echo_top** on the FPGA and the standalone **mcu_spi_test.c** program on the MCU. An older project bitstream will not produce this test's responses.

## 3. Program the FPGA first

### Lattice Radiant workflow

1. Create a separate SystemVerilog project targeting **iCE40UP5K, SG48**. Select the exact part/speed/package matching your course UPduino configuration.
2. Add **spi_echo.sv**. Set the top-level module to **spi_echo_top**.
3. Define the Verilog preprocessor symbol **RADIANT**, which selects the `HSOSC` primitive. Do not add the testbench to the hardware synthesis sources.
4. In the pin-assignment editor, set these package sites and use **LVCMOS33**:

   | Top-level port | FPGA site/pad | Board function |
   |---|---:|---|
   | `cs_n` | **20** | SW7-5, MCU PA11 |
   | `mosi` | **10** | SW7-6, MCU PB5 |
   | `miso` | **12** | SW7-7, MCU PB4 |
   | `sck` | **21** | SW7-8, MCU PB3 |
   | `heartbeat_led` | **42** | Blue LED D6 |
   | `accepted_led` | **38** | Blue LED D7 |
   | `rejected_led` | **28** | Blue LED D8 |

5. Use the internal oscillator configuration supplied in the source, nominally **24 MHz**, and check the clock/timing report. There is no external clock pin in this design.
6. Synthesize, place/route, and generate the programming file using your course workflow. Check the reported pin map before programming the UPduino.

The `.pcf` file is for the open-source flow; enter/translate its assignments in Radiant rather than assuming Radiant accepts PCF directly.

### Open-source workflow, if already installed

From this folder, run:

```powershell
.\build_fpga.ps1
```

This uses `yosys`, `nextpnr-ice40`, and `icepack`, and produces `build/spi_echo.bin`. Program it using your established UPduino programming procedure. This helper does not automatically flash a board or select a USB device.

### First FPGA observation

**Blue D6 should blink at approximately 1.4 Hz** while the FPGA is running. That shows that the bitstream and internal oscillator are active. It does not yet prove SPI.

Blue D7 toggles once per accepted 8-byte packet. Blue D8 latches on after a rejected frame and clears when this FPGA design resets/reconfigures. These are the carrier LEDs on P42/P38/P28, not the UPduino's RGB LED.

If D6 does not blink, fix FPGA programming, clock selection, power, or the pin assignment before debugging SPI.

## 4. Build and run the MCU test

Use a fresh **STM32L432KC / Cortex-M4** project in your normal MCU IDE, such as SEGGER Embedded Studio. Keep its normal device startup, vector table, system file, linker settings, and CMSIS headers.

1. Add **mcu_spi_test.c** as the only application source containing `main()`.
2. Ensure `stm32l432xx.h` and the CMSIS core headers are on the include path. The course lab project already supplies these.
3. Exclude the older application's `main.c`, board driver, interrupt handlers, and SPI library from this test build. In particular, do not call the old `initSPI()`: it chooses a different set of pins.
4. Use debug information and low/no optimization, preferably **-O0**, for the first test.
5. Build, program through ST-LINK, and run. The code sets its own **16 MHz HSI clock**, SPI1 mode 0, AF5 on PB3/PB4/PB5, and GPIO CS on PA11.

No UART terminal, `printf`, semihosting, DMA setup, or custom SysTick interrupt is needed. TIM2 supplies polling delays and timeouts. Leave SWD debugging enabled on PA13/PA14; do not enable SWO tracing on PB3 because PB3 is the SPI clock in this test.

Default speed is **125 kHz** and the code sends a frame approximately every **500 ms**. These defaults make the LED and debugger observations easy to follow.

## 5. Observe success in the debugger

Add **g_spi_test** to your IDE's Watch window and expand it. Run for several seconds, then pause to inspect stable values, or use the optional breakpoint at the `__NOP()` near the end of the main loop.

| Field | Expected behavior |
|---|---|
| `completed_frames` | Increases by approximately 2 per second |
| `pass_count` | Increases after the first warmup frame |
| `fail_count` | Remains **0** with a clean start and working link |
| `spi_timeouts` | Remains **0** |
| `result` | **0** during warmup, then **1** for passing comparisons |
| `mismatch_mask` | **0** |
| `last_tx[0..7]` | Actual most recent MCU transmission |
| `last_rx[0..7]` | Actual most recent FPGA reply |
| `expected_rx[0..7]` | Expected reply for the previous completed transmission |

After ten complete frames from a clean start, expect approximately **pass_count = 9, fail_count = 0**. The first frame is skipped for comparison because the FPGA has not received a previous test command yet.

Set byte-array display to **hexadecimal**. Do not interpret the bytes as an ASCII string: zeros and values such as `FF` are deliberate binary test data.

On the carrier, D7 should toggle roughly every half-second, D6 should continue its independent heartbeat, and D8 should stay off during clean traffic. MCU D13/PB3 and carrier D5 are connected to SCK and can flicker or appear dim/off; they are not pass/fail LEDs.

If you reprogram/reset the FPGA while the MCU is running, the reply pipeline resets and one or more mismatches can be expected. Establish the final FPGA program first, then reset the MCU and assess newly initialized counters. A startup glitch can latch D8; check signal idle states and repeat a clean start before treating it as evidence of ongoing errors.

## 6. What bytes should appear?

The MCU sends **8 bytes with CS low for all 64 clocks**:

```text
A5  sequence  00  FF  AA  55  (sequence XOR C3)  checksum
```

`checksum` is the XOR of the first seven bytes. The FPGA checks the header, frame length, and checksum. For accepted traffic, it returns a reply during the **next** transaction:

```text
5A  previous_sequence  FF  00  55  AA  inverted_previous_byte6  checksum
```

It preserves the sequence number and inverts each of payload bytes 2-6. This proves that data traveled **MCU -> FPGA**, was interpreted/transformed, and traveled **FPGA -> MCU**. An electrical MOSI/MISO short would return A5 and unchanged bytes, which fails this check.

The first two transactions should look like this:

| Transaction | MCU transmits | MCU receives |
|---:|---|---|
| 1 | `A5 01 00 FF AA 55 C2 66` | Startup response: `5A 00 00 00 00 00 00 5A` |
| 2 | `A5 02 00 FF AA 55 C1 66` | Reply to transaction 1: `5A 01 FF 00 55 AA 3D 66` |
| 3 | Sequence 3 frame | Reply to transaction 2: `5A 02 FF 00 55 AA 3E 66` |

The one-transaction delay is intentional. The FPGA cannot return a fully decoded command before it has received that command. The checksum stays `66` for these particular related patterns; the changing sequence and transformed byte are still verified individually. This simple XOR is a bring-up aid, not the final application's CRC.

## 7. If you have a logic analyzer or scope

The J6 breakout exposes the MCU-side signals even while the boards are plugged into the carrier:

| Analyzer connection | Net | J6 contact in the supplied schematic |
|---|---|---:|
| CS | PA11 | **12** |
| MOSI | PB5 | **11** |
| MISO | PB4 | **10** |
| SCK | PB3 | **9** |
| Ground | GND | **2 or 5** |

Use printed net labels/continuity to orient J6. Its contact numbers are the schematic symbol's pin numbers, not a substitute for identifying the physical header orientation. The supplied schematic draws two vertical columns with 1-20 on one side and 21-40 on the other; do not assume a conventional alternating numbering layout from the symbol name alone.

Decode **SPI mode 0, MSB first, 8-bit words, active-low CS**. At 125 kHz, 10 MS/s is ample; retain at least 10 MS/s for the later 1 MHz test, preferably more.

Trigger on **PA11/CS falling**. Expect:

- SCK idle **low** and CS idle **high**.
- At least **2 us** from CS falling to the first clock edge and from the final clock to CS rising.
- Exactly **64 SCK pulses** per selected frame.
- About **512 us of clocking** at 125 kHz, plus guards and software gaps between bytes.
- Correct TX bytes and the previous frame's transformed RX bytes.

Both boards share ground through the carrier; connect the analyzer ground to that logic ground. A scope is useful for voltage levels/ringing even when the digital decode appears plausible.

## 8. Then test at 1 MHz

After the slow test passes, change this line in mcu_spi_test.c:

```c
#define SPI_BAUD_BR 6u
```

to:

```c
#define SPI_BAUD_BR 3u
```

The test fixes the peripheral clock at 16 MHz, so BR = 3 gives **1 MHz**. Rebuild and reflash the MCU. Keep the 500 ms frame delay initially; clock speed and frame repetition rate are separate settings.

Require advancing pass counts and no new errors. For a longer run, set **TEST_DELAY_MS to 10u**, reset the counters by restarting the MCU, and collect at least **1000 passing comparisons** with no failures. Sequence wrap at 255 is normal. At the faster repetition rate D7 may appear steady because it toggles too quickly to resolve by eye; use counters or the analyzer.

This confirms the basic digital link at the intended SCK rate. It does not establish 5 kHz ADC/DMA scheduling, application CRC/command semantics, or control-loop operation.

## 9. Troubleshooting

| Observation | First checks |
|---|---|
| No D6 heartbeat | FPGA not programmed, wrong top module, oscillator primitive/define, pin map, power |
| No SCK at PB3 | MCU not running, stopped at breakpoint, wrong firmware, peripheral clock/AF5 |
| MCU timeouts/result 3 | Inspect timeout_stage: 1 TXE, 2 RXNE, 3 BSY, 4 SPI error flags; reset to retry |
| All RX bytes FF | SW7-7 open, FPGA unconfigured, wrong MISO site; MCU weak pull-up exposes an undriven bus |
| All RX bytes 00 | Wrong endpoint, output held low, FPGA held in reset, wrong bitstream |
| RX copies TX exactly | Accidental MOSI-MISO loopback; remove jumper and use the FPGA transformation |
| D6 blinks but D7 never changes | Check SW7-5/6/8, CS waveform, 64 clocks, MOSI header and checksum |
| D8 turns on | Truncated/overlong frame, corrupt bytes, wrong header, startup signal glitch; inspect decoded traffic |
| Every response looks one frame behind | Correct behavior; compare against previous TX, as the supplied C does |
| Passes slowly, fails at 1 MHz | Check edge timing, signal quality, correct mode, CS guards, MCU clock/divider |
| Old A4/A5/A6 wires or old pin assignments present | Remove them; this guide uses the carrier's PB3/PB4/PB5/PA11 route |

An open SPI wire ordinarily causes **wrong bytes**, not an MCU peripheral timeout: the MCU can still generate clocks and complete a transfer with no slave attached. Read the byte comparisons as well as the timeout counter.

## 10. Validation and limits

The supplied HDL testbench checks 125 kHz and 1 MHz transfers, 300 valid frames including sequence wrap, transformed replies, bad-checksum rejection, short/long frame rejection, wrong-header rejection, recovery, reset, and deselected MISO release. Run it with installed Icarus tools:

```powershell
.\run_sim.ps1
```

Checks completed on November 7, 2026:

- The MCU source compiled for Cortex-M4 with warnings treated as errors at both 125 kHz and 1 MHz settings, using the course CMSIS/device headers.
- The HDL simulation passed all cases described above using Icarus Verilog 13.0.
- The FPGA top level synthesized and placed/routed for iCE40UP5K-SG48 with the supplied pad assignments: **294/5280 logic cells**, with a reported **50.71 MHz maximum internal clock frequency**, passing the **24 MHz** requirement. Tools were YoWASP Yosys 0.70 and nextpnr-ice40 0.11.1. Yosys issued its generic limited-tristate-support warning; nextpnr mapped the MISO output-enable to an I/O pad. Simulation checks its deselected release; electrical release still needs a bench check.

Hardware flashing, physical switch continuity, actual voltage levels, and on-board pass counters still need the bench procedure above. MCU source compilation is not a full executable link or proof of flashing. FPGA routing estimates do not establish real external SPI setup/hold margins.

The later levitation design can use the same carrier SPI route if its MCU driver and FPGA constraints are changed to this map together. The existing explicit-jumper guide and application pin files do not automatically adopt it.

## Sources

- [E155 development-board schematic, Rev v4](https://hmc-e155.github.io/assets/doc/E155%20Development%20Board%20Schematic.pdf): SW7 mapping, J3/J4 power connections, LEDs, and J6 nets.
- [E155 resources](https://hmc-e155.github.io/resources/): course board and programming documentation.
- [STM32L432KC datasheet, Table 15](https://hmc-e155.github.io/assets/doc/ds11451-stm32l432kc.pdf): PB3/PB4/PB5 AF5 SPI1 mapping; PA11 is software-controlled GPIO CS here.
- [Nucleo-32 manual](https://hmc-e155.github.io/assets/doc/um1956-stm32-nucleo32-boards-mb1180-stmicroelectronics.pdf): Nucleo connector and debugger information.
- [UPduino specifications and pinout](https://upduino.readthedocs.io/en/latest/features/specs.html): UPduino I/O labels and device information.
