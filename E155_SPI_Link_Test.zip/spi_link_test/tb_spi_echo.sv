`timescale 1ns/1ps
module tb_spi_echo;
    reg clk=0,rst=1,sck=0,cs_n=1,mosi=0;
    wire miso,accepted_led,rejected_led;
    wire [31:0] accepted_count,rejected_count;
    always #20.833333 clk=~clk;
    spi_echo_core dut(.*);
    function automatic [7:0] xor7(input [55:0] b);
        begin xor7=0; for(integer j=0;j<7;j=j+1) xor7=xor7 ^ b[j*8+:8]; end
    endfunction
    function automatic [63:0] command(input [7:0] seq);
        reg [55:0] b;
        begin b={8'ha5,seq,8'h00,8'hff,8'haa,8'h55,(seq^8'hc3)};
            command={b,xor7(b)}; end
    endfunction
    function automatic [63:0] response(input [63:0] tx);
        reg [55:0] b;
        begin b={8'h5a,tx[55:48],~tx[47:8]}; response={b,xor7(b)}; end
    endfunction
    task automatic transfer(input [63:0] tx,input integer half_ns,
                             input integer bits,output reg [63:0] rx);
        begin
            rx=0; sck=0; cs_n=0; #2000;
            for(integer k=0;k<bits;k=k+1) begin
                mosi=tx[63-(k%64)]; #(half_ns);
                sck=1; #100; rx={rx[62:0],miso}; #(half_ns-100); sck=0;
            end
            #2000; cs_n=1; #10000;
            if(miso!==1'bz) $fatal(1,"MISO not released while deselected");
        end
    endtask
    reg [63:0] tx,rx,expected=64'h5a0000000000005a;
    integer count_before;
    initial begin
        #1000; rst=0; #10000;
        // Verify complete payload/response, sequence wrap, and both SCK rates.
        for(integer n=1;n<=300;n=n+1) begin
            tx=command(8'(n));
            transfer(tx,n<5?4000:500,64,rx);
            if(rx!==expected) $fatal(1,"Reply mismatch n=%0d rx=%h expected=%h",n,rx,expected);
            expected=response(tx);
        end
        if(accepted_count!=300 || rejected_count!=0 || rejected_led)
            $fatal(1,"Unexpected acceptance/rejection counts");
        count_before=accepted_count;
        tx=command(8'h7a)^64'h1; transfer(tx,500,64,rx);
        if(rx!==expected || accepted_count!=count_before || rejected_count!=1)
            $fatal(1,"Corrupt XOR accepted or reply changed");
        tx=command(8'h7b); transfer(tx,500,63,rx);
        if(accepted_count!=count_before || rejected_count!=2) $fatal(1,"Short frame accepted");
        transfer(tx,500,65,rx);
        if(accepted_count!=count_before || rejected_count!=3) $fatal(1,"Long frame accepted");
        tx=command(8'h7c); tx[63:56]=8'h33; tx[7:0]=xor7(tx[63:8]);
        transfer(tx,500,64,rx);
        if(accepted_count!=count_before || rejected_count!=4) $fatal(1,"Wrong header accepted");
        // Recovery after malformed frames, and reset reply behavior.
        tx=command(8'h7d); transfer(tx,500,64,rx);
        if(rx!==expected || accepted_count!=301 || !rejected_led) $fatal(1,"No recovery");
        expected=response(tx); transfer(command(8'h7e),500,64,rx);
        if(rx!==expected) $fatal(1,"Recovered response mismatch");
        rst=1; #1000; rst=0; #10000;
        transfer(command(8'h01),500,64,rx);
        if(rx!==64'h5a0000000000005a || accepted_count!=1 || rejected_count!=0)
            $fatal(1,"Reset did not restore startup state");
        $display("PASS: 125 kHz/1 MHz, 300 frames and sequence wrap, exact echo, malformed rejection, MISO release, recovery, reset");
        $finish;
    end
    initial begin #100000000; $fatal(1,"Simulation timeout"); end
endmodule
