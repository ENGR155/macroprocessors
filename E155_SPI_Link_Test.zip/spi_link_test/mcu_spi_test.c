/* Standalone STM32L432KC test: add to a fresh CMSIS STM32L432KC project.
 * Own main() only; use the IDE's normal device startup/system files.
 * SW7 5-8 ON routes PA11/PB5/PB4/PB3 to FPGA P20/P10/P12/P21.
 * This deliberately does not call the older lab initSPI() pin assignment.
 */
#include <stdint.h>
#include <stdbool.h>
#include "stm32l432xx.h"

#ifndef SPI_BAUD_BR
#define SPI_BAUD_BR 6u       /* 16 MHz / 128 = 125 kHz. Set 3u for 1 MHz. */
#endif
#ifndef TEST_DELAY_MS
#define TEST_DELAY_MS 500u  /* Slow enough to observe accepted-frame LED. */
#endif

typedef struct {
    uint32_t completed_frames, pass_count, fail_count, spi_timeouts;
    uint32_t result;        /* 0=warmup, 1=pass, 2=mismatch, 3=SPI timeout */
    uint32_t timeout_stage; /* 1=TXE, 2=RXNE, 3=BSY, 4=SPI error flags */
    uint32_t mismatch_mask;
    uint8_t last_tx[8], last_rx[8], expected_rx[8];
} spi_test_results_t;
volatile spi_test_results_t g_spi_test;

static uint32_t now_us(void) { return TIM2->CNT; }
static void delay_us(uint32_t us) {
    uint32_t start=now_us();
    while((uint32_t)(now_us()-start)<us) { __NOP(); }
}
static void pin_mode(GPIO_TypeDef *g,unsigned pin,unsigned mode) {
    g->MODER=(g->MODER&~(3u<<(2u*pin)))|(mode<<(2u*pin));
}
static void pin_af(GPIO_TypeDef *g,unsigned pin,unsigned af) {
    unsigned index=pin/8u,shift=4u*(pin%8u);
    g->AFR[index]=(g->AFR[index]&~(15u<<shift))|(af<<shift);
    g->OTYPER&=~(1u<<pin);
    g->OSPEEDR=(g->OSPEEDR&~(3u<<(2u*pin)))|(2u<<(2u*pin));
    g->PUPDR&=~(3u<<(2u*pin));
    pin_mode(g,pin,2u);
}
static void init_test(void) {
    RCC->CR|=RCC_CR_HSION;
    while(!(RCC->CR&RCC_CR_HSIRDY)) {}
    RCC->CFGR=(RCC->CFGR&~RCC_CFGR_SW)|RCC_CFGR_SW_HSI;
    while((RCC->CFGR&RCC_CFGR_SWS)!=RCC_CFGR_SWS_HSI) {}
    RCC->CFGR&=~(RCC_CFGR_HPRE|RCC_CFGR_PPRE1|RCC_CFGR_PPRE2);
    SystemCoreClock=16000000u;
    RCC->AHB2ENR|=RCC_AHB2ENR_GPIOAEN|RCC_AHB2ENR_GPIOBEN;
    (void)RCC->AHB2ENR;
    /* Set CS high before enabling the output; park old permit/CS pins safely. */
    GPIOA->BSRR=(1u<<11)|(1u<<4)|(1u<<1)|(1u<<16);
    GPIOA->OTYPER&=~((1u<<11)|(1u<<4)|(1u<<1)|1u);
    pin_mode(GPIOA,11,1); pin_mode(GPIOA,4,1);
    pin_mode(GPIOA,1,1); pin_mode(GPIOA,0,1);
    GPIOA->PUPDR=(GPIOA->PUPDR&~(3u<<22))|(1u<<22);
    pin_af(GPIOB,3,5); /* SCK: D13 -> SW7-8 -> FPGA P21 */
    pin_af(GPIOB,4,5); /* MISO: D12 <- SW7-7 <- FPGA P12 */
    pin_af(GPIOB,5,5); /* MOSI: D11 -> SW7-6 -> FPGA P10 */
    GPIOB->PUPDR|=1u<<(2u*4u); /* Weak MISO pull-up: floating bus tends to FF. */
    RCC->APB1ENR1|=RCC_APB1ENR1_TIM2EN;
    (void)RCC->APB1ENR1;
    TIM2->CR1=0; TIM2->PSC=15; TIM2->ARR=0xffffffffu;
    TIM2->EGR=TIM_EGR_UG; TIM2->CNT=0; TIM2->CR1=TIM_CR1_CEN;
    RCC->APB2ENR|=RCC_APB2ENR_SPI1EN;
    (void)RCC->APB2ENR;
    RCC->APB2RSTR|=RCC_APB2RSTR_SPI1RST;
    RCC->APB2RSTR&=~RCC_APB2RSTR_SPI1RST;
    SPI1->CR1=SPI_CR1_MSTR|SPI_CR1_SSM|SPI_CR1_SSI|
              (SPI_BAUD_BR<<SPI_CR1_BR_Pos); /* CPOL=CPHA=0; MSB first */
    SPI1->CR2=(7u<<SPI_CR2_DS_Pos)|SPI_CR2_FRXTH;
    SPI1->CR1|=SPI_CR1_SPE;
}
static bool wait_sr(uint32_t mask,bool set,uint32_t stage) {
    uint32_t start=now_us();
    while(((SPI1->SR&mask)!=0)!=set) {
        if((uint32_t)(now_us()-start)>5000u) {
            g_spi_test.spi_timeouts++; g_spi_test.timeout_stage=stage;
            return false;
        }
    }
    return true;
}
static bool exchange(const uint8_t tx[8],uint8_t rx[8]) {
    GPIOA->BSRR=1u<<(11u+16u); delay_us(2);
    for(unsigned i=0;i<8;i++) {
        if(!wait_sr(SPI_SR_TXE,true,1)) goto failed;
        *(volatile uint8_t *)&SPI1->DR=tx[i];
        if(!wait_sr(SPI_SR_RXNE,true,2)) goto failed;
        rx[i]=*(volatile uint8_t *)&SPI1->DR;
    }
    if(!wait_sr(SPI_SR_BSY,false,3)) goto failed;
    if(SPI1->SR&(SPI_SR_OVR|SPI_SR_MODF)) {
        g_spi_test.spi_timeouts++; g_spi_test.timeout_stage=4; goto failed;
    }
    delay_us(2); GPIOA->BSRR=1u<<11; delay_us(10);
    return true;
failed:
    GPIOA->BSRR=1u<<11;
    return false;
}
static uint8_t xor7(const uint8_t b[8]) {
    uint8_t x=0;
    for(unsigned i=0;i<7;i++) x^=b[i];
    return x;
}
int main(void) {
    uint8_t tx[8],rx[8]={0},expected[8]={0};
    uint8_t seq=1;
    bool have_expected=false;
    init_test();
    delay_us(10000); /* FPGA must already be configured; program it first. */
    for(;;) {
        tx[0]=0xa5; tx[1]=seq; tx[2]=0x00; tx[3]=0xff;
        tx[4]=0xaa; tx[5]=0x55; tx[6]=(uint8_t)(seq^0xc3u);
        tx[7]=xor7(tx);
        for(unsigned i=0;i<8;i++) {
            g_spi_test.last_tx[i]=tx[i];
            g_spi_test.expected_rx[i]=expected[i];
        }
        if(!exchange(tx,rx)) {
            g_spi_test.result=3;
            for(;;) { __NOP(); } /* Halt here to inspect stage; reset to retry. */
        }
        for(unsigned i=0;i<8;i++) g_spi_test.last_rx[i]=rx[i];
        g_spi_test.completed_frames++;
        if(have_expected) {
            uint32_t mismatch=0;
            for(unsigned i=0;i<8;i++) if(rx[i]!=expected[i]) mismatch|=1u<<i;
            g_spi_test.mismatch_mask=mismatch;
            if(mismatch) { g_spi_test.fail_count++; g_spi_test.result=2; }
            else { g_spi_test.pass_count++; g_spi_test.result=1; }
        }
        /* Next reply echoes this sequence and inverts payload bytes 2-6. */
        expected[0]=0x5a; expected[1]=seq;
        for(unsigned i=2;i<7;i++) expected[i]=(uint8_t)~tx[i];
        expected[7]=xor7(expected);
        have_expected=true; seq++;
        __NOP(); /* Optional breakpoint: completed frame and stable watch data. */
        for(uint32_t ms=0;ms<TEST_DELAY_MS;ms++) delay_us(1000);
    }
}
